package com.kyh.heera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeeraApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeeraApplication.class, args);
	}

}
